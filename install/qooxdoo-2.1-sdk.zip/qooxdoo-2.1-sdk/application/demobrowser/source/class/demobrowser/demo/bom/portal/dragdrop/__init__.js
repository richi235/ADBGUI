/**
 * Implementation of the drag and drop manager.
 */